This is a chrome browser extension.

- This extension scrapes youtubes webpage by the recomended video css selector, and gets links from them.

- Then it creates a playlist named TV (or picks the latest playlist named TV, which you already have)

- Then it pulls the recomended videos into that playlist and redirects you to that playlist

- ATTENTION the app globaly can only be used 10 times a day. By me, and you and your friend combined. This is because youtube limits how many api calls you can make to a day. (10 by this use case. That is equivelent to adding approximatley 200 videos to an existing TV playlist )

- To unleash this script's full potential (and have all of those 10 api calls all to yoursel) you need to take this app and get Your unique chrome extension app key.

- If your interested in doing that, you can write to me and I can point you to the one toturial you will need to go through to do that.




To install it you need to download it (or clone it in a dir)

- Open chrome go to -> more tools -> extensions -> turn on developer mode -> and press on "load unpacked"


To use it

1. You need to be logged into chrome browser and have "Sync" turned on

2. You need to be logged into your youtube account with the same login. (works on all of your youtube accounts registered to the same user)